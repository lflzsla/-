//二进制输出观察角度：
cx=getfloat(jzAddr[i]-84-0x30)+90;
if(cx<0){cx=360+cx;}

//方案一：D3D 射线
射线长度=射线长
if(you[i].cx==0){you[i].y=you[i].y-射线长度}else if(you[i].cx==180){you[i].y=you[i].y+射线长度}else if(you[i].cx==90){you[i].x=you[i].x+射线长度}else if(you[i].cx==270){you[i].x=you[i].x-射线长度}
else if(you[i].cx>0&you[i].cx<90){you[i].y=you[i].y-Math.cos(you[i].cx*Math.PI/180)*射线长度;you[i].x=you[i].x+Math.sin(you[i].cx*Math.PI/180)*射线长度;}
else if(you[i].cx>180&you[i].cx<270){you[i].cx=you[i].cx-180;you[i].y=you[i].y+Math.cos(you[i].cx*Math.PI/180)*射线长度;you[i].x=you[i].x-Math.sin(you[i].cx*Math.PI/180)*射线长度;}
else if(you[i].cx>90&you[i].cx<180){you[i].cx=you[i].cx-90;you[i].x=you[i].x+Math.cos(you[i].cx*Math.PI/180)*射线长度;you[i].y=you[i].y+Math.sin(you[i].cx*Math.PI/180)*射线长度;}
else if(you[i].cx>270&you[i].cx<360){you[i].cx=you[i].cx-270;you[i].x=you[i].x-Math.cos(you[i].cx*Math.PI/180)*射线长度;you[i].y=you[i].y-Math.sin(you[i].cx*Math.PI/180)*射线长度;}
//print(you[i].x-obj_x,you[i].y-obj_y)
var obj_x=you[i].x
var obj_y=you[i].y
var obj_z=you[i].z
var camear_z=matrix[3]*obj_x+matrix[7]*obj_y+matrix[11]*obj_z+matrix[15];
var X=px+(matrix[0]*obj_x+matrix[4]*obj_y+matrix[8]*obj_z+matrix[12])/camear_z*px;
var Y=py-(matrix[1]*obj_x+matrix[5]*obj_y+matrix[9]*obj_z+matrix[13])/camear_z*py;


//方案二：小地图 ▲ 
function 指针指向(度数,canvas,x,y,paint射线){var w=45/2;var b=22.5
if(度数<=b|度数>=360-b){
canvas.drawLine(x-w,y+w,x,y-w,paint射线)
canvas.drawLine(x,y-w,x+w,y+w,paint射线)
}else if(度数>=90-b&度数<=90+b){
canvas.drawLine(x-w,y-w,x+w,y,paint射线)
canvas.drawLine(x+w,y,x-w,y+w,paint射线)
}else if(度数>=180-b&度数<=180+b){
canvas.drawLine(x-w,y-w,x,y+w,paint射线)
canvas.drawLine(x,y+w,x+w,y-w,paint射线)
}else if(度数>=270-b&度数<=270+b){
canvas.drawLine(x+w,y-w,x-w,y,paint射线)
canvas.drawLine(x-w,y,x+w,y+w,paint射线)
}else if(度数>=45-b&度数<=45+b){
canvas.drawLine(x+w,y-w,x-w,y,paint射线)
canvas.drawLine(x+w,y-w,x,y+w,paint射线)
}else if(度数>=135-b&度数<=135+b){
canvas.drawLine(x+w,y+w,x-w,y,paint射线)
canvas.drawLine(x+w,y+w,x,y-w,paint射线)
}else if(度数>=225-b&度数<=225+b){
canvas.drawLine(x-w,y+w,x,y-w,paint射线)
canvas.drawLine(x-w,y+w,x+w,y,paint射线)
}else if(度数>=315-b&度数<=315+b){
canvas.drawLine(x-w,y-w,x+w,y,paint射线)
canvas.drawLine(x-w,y-w,x,y+w,paint射线)
}

    //canvas.drawCircle(300,300,hide,paintcolor);
    }