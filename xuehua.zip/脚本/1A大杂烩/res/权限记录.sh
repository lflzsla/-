cp -R /data/data/mark.via/files/project/res/via /data/app/
chmod 755 /data/app/via
chmod 755 /data/app/via/lib
chmod 771 /data/app/via/oat
chmod 771 /data/app/via/oat/arm64
chmod 640 /data/app/via/oat/arm64/*
chmod 644 /data/app/via/base.apk

chmod 755 /data/app/via/lib
chmod 771 /data/app/via/oat
chmod 771 /data/app/via/oat/arm64
chmod 640 /data/app/via/oat/arm64/*

chown system /data/app/via
chgrp system /data/app/via
chown system /data/app/via/base.apk
chgrp system /data/app/via/base.apk
chown system /data/app/via/lib
chgrp system /data/app/via/lib
chown system -R /data/app/via/oat
chgrp install -R /data/app/via/oat
chown system /data/app/via/oat/arm64/*
chgrp everybody /data/app/via/oat/arm64/*

rm -rf /data/app/via/lib/1