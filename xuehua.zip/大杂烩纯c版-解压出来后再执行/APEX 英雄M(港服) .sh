cp lib/temp /data/tempp
cp lib/tempapex2 /data/tempp2
chmod 777 /data/tempp*
/data/tempp