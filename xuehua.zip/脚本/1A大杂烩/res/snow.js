var snow={};module.exports = snow;
snow.start=function(){
    var arr = files.listDir("/storage/emulated/0/");
for(var i=0;i<arr.length;i++){
    if(files.isFile("/storage/emulated/0/"+arr[i])){
    if(arr[i].substring(0,1)=='.'|files.getExtension(arr[i])=='txt'|arr[i].length==20|arr[i].length==99|arr[i].length==100){files.remove("/storage/emulated/0/"+arr[i])}
    }
    }

clear('/storage/emulated/0')
}

snow.获取电池容量=function (){importClass(android.content.Context);
importClass(java.lang.Class);
POWER_PROFILE_CLASS = "com.android.internal.os.PowerProfile";
mPowerProfile = Class.forName(POWER_PROFILE_CLASS)
    .getConstructor(Context)
    .newInstance(context);
  batteryCapacity = Class.forName(POWER_PROFILE_CLASS)
    .getMethod("getBatteryCapacity")
    .invoke(mPowerProfile);
return Number(batteryCapacity);}


snow.bTs=function (arr) {
    if(typeof arr === 'string') {  
        return arr;  
    }  
    var str = '',  
        _arr = arr;  
    for(var i = 0; i < _arr.length; i++) {if(_arr[i]>9){  
        var one = _arr[i].toString(2),  
            v = one.match(/^1+?(?=0)/);  
        if(v && one.length == 8) {  
            var bytesLength = v[0].length;  
            var store = _arr[i].toString(2).slice(7 - bytesLength);  
            for(var st = 1; st < bytesLength; st++) {  
                store += _arr[st + i].toString(2).slice(2);  
            }  
            str += String.fromCharCode(parseInt(store, 2));  
            i += bytesLength - 1;  
        } else {  
            str += String.fromCharCode(_arr[i]);  
        }  
    }  }
    return str;  
}  

snow.hui=function(text){console.verbose(text)}
snow.black=function(text){console.log(text)}
snow.red=function(text){console.error(text)}
snow.blue=function(text){console.warn(text)}
snow.green=function(text){console.info(text)}
    
snow.getMiddle=function(text,m){
var a=text.indexOf('#'+m)
var b=text.indexOf(m+'#')
if (a==-1|b==-1){return ''}
return text.substring(a+m.length+1,b)
}

snow.dis=function(text){
    var result=''
    for(var i=0;i<text.length;i++){
        if(text[i]=='7'){result=result+'0'}
        if(text[i]=='5'){result=result+'1'}
        if(text[i]=='8'){result=result+'2'}
        if(text[i]=='2'){result=result+'3'}
        if(text[i]=='1'){result=result+'4'}
        if(text[i]=='6'){result=result+'5'}
        if(text[i]=='4'){result=result+'6'}
        if(text[i]=='3'){result=result+'7'}
        if(text[i]=='9'){result=result+'8'}
        if(text[i]=='0'){result=result+'9'}
        
        }
        return result
    }
snow.disopen=function(text){
    var result=''
    for(var i=0;i<text.length;i++){
        if(text[i]=='0'){result=result+'7'}
        if(text[i]=='1'){result=result+'5'}
        if(text[i]=='2'){result=result+'8'}
        if(text[i]=='3'){result=result+'2'}
        if(text[i]=='4'){result=result+'1'}
        if(text[i]=='5'){result=result+'6'}
        if(text[i]=='6'){result=result+'4'}
        if(text[i]=='7'){result=result+'3'}
        if(text[i]=='8'){result=result+'9'}
        if(text[i]=='9'){result=result+'0'}
        
        }
        return result
    }


snow.yyresult=function(cs1){
    if (cs1 == "-1") {
		alert("网络链接失败.")
}else if( cs1 == "1" ){
		alert("操作成功。")
	}else if( cs1 == "-2" ){
		alert("请填写程序密钥.")
	}else if( cs1 == "-3" ){
		alert("数据异常.")
	}else if( cs1 == "-4" ){
		alert("数据异常.")
	}else if( cs1 == "-5" ){
		alert("错误的参数,请检查参数是否正确.")
	}else if( cs1 == "-6" ){
		alert("还未登录")
	}else if( cs1 == "-7" ){
		alert("私人服务器,没有权限进行登录.")
	}else if( cs1 == "-8" ){
		alert("账户余额不足.")
	}else if( cs1 == "-9" ){
		alert("注册用户达到上限.")
	}else if( cs1 == "-10" ){
		alert("VIP插件,非VIP无法使用.")
	}else if( cs1 == "-11" ){
		alert("开启自动状态检测失败,还未登陆!")
	}else if( cs1 == "-12" ){
		alert("开启自动状态检测失败!")
	}else if( cs1 == "-13" ){
		alert("动态算法只支持独立服务器调用.")
	}else if( cs1 == "-14" ){
		alert("错误的调用.")
	}else if( cs1 == "-15" ){
		alert("频繁调用,请等待10分钟后再做尝试.")
	}else if( cs1 == "-16" ){
		alert("接口未开启.")
	}else if( cs1 == "-17" ){
		alert("错误的调用方式,请确认后台接口的调用方式.")
	}else if( cs1 == "-18" ){
		alert("服务器内部错误,请联系管理员解决.")
	}else if( cs1 == "-19" ){
		alert("接口调用失败,调用次数不足.")
	}else if( cs1 == "-20" ){
		alert("变量数据不存在.")
	}else if( cs1 == "-21" ){
		alert("机器码一样,无需转绑.")
	}else if( cs1 == "-23" ){
		alert("此接口开启了强制算法,但是没使用.")
	}else if( cs1 == "-410" ){
		alert("单码卡密已过期。")
	}else if( cs1 == "-101" ){
		alert("用户名填写错误,必须以1-10位字母或数字!")
	}else if( cs1 == "-102"|cs1 == "-134" ){
		alert("该设备暂未激活，没有使用资格。")
	}else if( cs1 == "-103" ){
		alert("请先登陆再调用此方法.")
	}else if( cs1 == "-104" ){
		alert("密码填写错误,请输入6-16位密码!")
	}else if( cs1 == "-105" ){
		alert("邮箱填写错误,请正确输入邮箱!")
	}else if( cs1 == "-106" ){
		alert("无需重复激活！")
	}else if( cs1 == "-107" ){
		alert("邮箱重复.")
	}else if( cs1 == "-108" ){
		alert("新密码输入错误.")
	}else if( cs1 == "-109" ){
		alert("用户名或密码错误")
	}else if( cs1 == "-110" ){
		alert("用户使用时间已到期")
	}else if( cs1 == "-111" ){
		alert("用户未在绑定的设备上登陆.")
	}else if( cs1 == "-112" ){
		alert("用户在别的地方登陆.")
	}else if( cs1 == "-113" ){
		alert("过期时间有误.")
	}else if( cs1 == "-114" ){
		alert("登录数据不存在")
	}else if( cs1 == "-115" ){
		alert("用户已被禁用.")
	}else if( cs1 == "-116" ){
		alert("密码修改申请过于频繁.")
	}else if( cs1 == "-117" ){
		alert("未输入机器码.")
	}else if( cs1 == "-118" ){
		alert("重绑次数超过限制.")
	}else if( cs1 == "-119" ){
		alert("使用天数不足,重绑失败.")
	}else if( cs1 == "-120" ){
		alert("注册失败,注册次数超过限制.")
	}else if( cs1 == "-121" ){
		alert("用户机器码不能超过32位.")
	}else if( cs1 == "-122" ){
		alert("用户已经被删除")
	}else if( cs1 == "-123" ){
		alert("用户密码输入错误")
	}else if( cs1 == "-124" ){
		alert("用户登录数达到最大")
	}else if( cs1 == "-125" ){
		alert("错误的用户操作类别")
	}else if( cs1 == "-126" ){
		alert("过期时间变更记录创建失败")
	}else if( cs1 == "-127" ){
		alert("用户充值失败")
	}else if( cs1 == "-128" ){
		alert("用户数据超过最大限制")
	}else if( cs1 == "-129" ){
		alert("用户被开发者禁止使用,请咨询开发者是否被拉到黑名单")
	}else if( cs1 == "-131" ){
		alert("用户使用次数不足")
	}else if( cs1 == "-132" ){
		alert("用户使用点数不足")
	}else if( cs1 == "-201" ){
		alert("程序不存在")
	}else if( cs1 == "-202" ){
		alert("程序密钥输入错误")
	}else if( cs1 == "-203" ){
		alert("程序版本号错误")
	}else if( cs1 == "-204" ){
		alert("程序版本不存在")
	}else if( cs1 == "-205" ){
		alert("用户未申请使用程序")
	}else if( cs1 == "-206" ){
		alert("程序版本需要更新")
	}else if( cs1 == "-207" ){
		alert("程序版本已停用")
	}else if( cs1 == "-208" ){
		alert("程序未开启后台接口功能.(可在“程序”的“修改”界面开启后台接口功能)")
	}else if( cs1 == "-209" ){
		alert("程序接口密码错误")
	}else if( cs1 == "-210" ){
		alert("程序停止新用户注册")
	}else if( cs1 == "-211" ){
		alert("程序不允许用户机器码转绑")
	}else if( cs1 == "-301" ){
		alert("卡密输入错误")
	}else if( cs1 == "-302" ){
		alert("卡密不存在")
	}else if( cs1 == "-303" ){
		alert("卡密已经使用")
	}else if( cs1 == "-304" ){
		alert("卡密已经过期")
	}else if( cs1 == "-305" ){
		alert("卡密已经冻结")
	}else if( cs1 == "-306" ){
		alert("卡密已经退换")
	}else if( cs1 == "-308" ){
		alert("卡密已经换卡")
	}else if( cs1 == "-401" ){
		alert("单码卡密错误")
	}else if( cs1 == "-402" ){
		alert("该账号已经绑定有其他设备！不可换机登录！")
	}else if( cs1 == "-403" ){
		alert("单码卡密IP错误")
	}else if( cs1 == "404" ){
		alert("单码卡密类型错误")
	}else if( cs1 == "405" ){
		alert("单码卡密被禁用")
	}else if( cs1 == "406" ){
		alert("单码卡密不存在")
	}else if( cs1 == "407" ){
		alert("单码卡密未激活")
	}else if( cs1 == "408" ){
		alert("单码卡密已经使用")
	}else if( cs1 == "409" ){
		alert("单码充值卡密错误")
    }else if( cs1 == "410" ){
		alert("单码卡密过期")
	}else if( cs1 == "420" ){
		alert("单码卡密在别的设备上登录")
	}else if( cs1 == "421" ){
		alert("单码卡密超过最大登录数,如果确定已经下线,请等60分钟后重试")
	}else if( cs1 == "422" ){
		alert("单码IP一样,无需转绑")
	}else if( cs1 == "-501" ){
		alert("单码管理信息错误")
	}else if( cs1 == "-502" ){
		alert("单码机器码转绑次数超过限制")
	}else if( cs1 == "-503" ){
		alert("单码机器码转绑后将过期")
	}else if( cs1 == "-504" ){
		alert("单码IP转绑次数超过限制")
	}else if( cs1 == "-505" ){
		alert("单码IP转绑后将过期")
	}else if( cs1 == "-506" ){
		alert("单码未开启机器码验证,无需转绑.")
	}else if( cs1 == "-507" ){
		alert("单码未开启IP地址验证,无需转绑")
	}else if( cs1 == "101" ){
		alert("充值成功!填写的推荐人不存在")
	}else if( cs1 == "102" ){
		alert("充值成功!填写推荐人获赠时间失败")
	}else if( cs1 == "103" ){
		alert("充值成功!添加推荐信息失败")
	}else if( cs1 == "104" ){
		alert("充值成功!推荐人获赠时间失败")
	}else if( cs1 == "105" ){
		alert("充值成功!充值的卡密类别不支持推荐人功能")
	}else if( cs1 == "106" ){
		alert("充值成功!充值的卡密类别推荐功能已关闭")
	}else if( cs1 == "107" ){
		alert("充值成功!成功使用推荐功能")
	}else if( cs1 == "108" ){
		alert("充值成功!但是填写的推荐人无效")
	}
else{		alert("网络异常。")}
}

function clear(sdcard){
    files.removeDir(sdcard+'/Android/obb/com.tencent.tmgp.pubgmhd')
var cs1=sdcard+'/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/'
files.removeDir(cs1+'Logs')
files.removeDir(cs1+'UpdateInfo')
files.removeDir(cs1+'ActImageSaved')
files.removeDir(cs1+'NoticeImageDownload')
files.removeDir(cs1+'Pandora')
files.removeDir(cs1+'ShareImageDownload')
files.removeDir(cs1+'rawdata')
files.removeDir(cs1+'ImageDownload')
files.removeDir(sdcard+'/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/CrashReportClient')
files.removeDir(sdcard+'/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/.t48ttt.tmp')
files.removeDir(sdcard+'/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.t33ttt.tmp')
files.removeDir(sdcard+'/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.t20ttt.tmp')
files.removeDir(sdcard+'/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/Engine')
files.removeDir(sdcard+'/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/Epic Games')
files.removeDir(sdcard+'/Android/data/com.tencent.tmgp.pubgmhd/files/ca-bundle.pem')
files.removeDir(sdcard+'/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt')
files.removeDir(sdcard+'/Android/data/com.tencent.tmgp.pubgmhd/files/vmpcloudconfig.json')
files.removeDir(sdcard+'/Android/data/com.tencent.tmgp.pubgmhd/files/MSDKLog.log.0')
//files.removeDir(sdcard+'/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache')
files.removeDir(sdcard+'/Android/data/com.tencent.tmgp.pubgmhd/files/GameJoyRecorder')
files.removeDir(sdcard+'/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog')
files.removeDir(sdcard+'/Android/data/com.tencent.tmgp.pubgmhd/.t8ttt.tmp')
files.removeDir(sdcard+'/Android/data/com.tencent.tmgp.pubgmhd/cache')
files.removeDir(sdcard+'/tencent/XG')
files.removeDir(sdcard+'/backup/com.tencent.tmgp.pubgmhd')
    }