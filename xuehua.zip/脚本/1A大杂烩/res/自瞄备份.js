if(自瞄菜单开关){if(matrix[16]>10000){me.zt=60}
ccc=Math.sqrt(Math.pow(Math.abs(x+w/2-px),2)+Math.pow(Math.abs(y+h/2-py),2))
if(强锁){ccc=ccc*you[i].f;if(you[i].q==30){ccc=ccc*2}}
//if(x+w/2>0&x+w/2<px*2&ccc<haha&you[i].q!=30){haha=ccc
        自瞄范围1=px*2/5;自瞄范围2=px*2-px*2/5
        if(x+w/2>自瞄范围1&x+w/2<自瞄范围2&y+h/2>0&y+h/2<py*2&ccc<haha&you[i].f>2&me.x!=0){haha=ccc;if(强锁){锁定敌人=x};排除地址=you[i].address
        
        zmdown=0;if(you[i].ztt==1){zmdown=47}else if(you[i].ztt==2){zmdown=20}else if(you[i].ztt==3){zmdown=-40}else if(you[i].ztt==4){zmdown=-40}//30 45 40
        
        var perx=you[i].x-matrix[21];var pery=you[i].y-matrix[22];
        //var perx=you[i].x-me.x;var pery=you[i].y-me.y;
        var perz=you[i].z-matrix[23]+zmdown;
        
        setPery=57.3*(Math.atan2(perz,Math.sqrt(perx*perx+pery*pery)))-you[i].f*(0.09/400)//校准远距离
        //二次修正=0;if(you[i].f>25){二次修正=0.25}
        //下压幅度修正=下压幅度;if(you[i].ztt==1&下压幅度修正==0.55&you[i].f<40){下压幅度修正=you[i].f*(0.55/40)}
        setPerx=57.3*(Math.atan2(pery,perx))
        //setPerx=setPerx-0.3;if((x+w/2-px)<0){setPerx=setPerx-0.1}else{setPerx=setPerx+0.25}//0.0025}
        var 随机=random()*0.1;if(随机>0.05){随机=-(随机-0.05)}
        随机=随机/4;//print(随机);
        //下压幅度修正=0;随机=0测试使用
        //下压幅度=0
        setPerx=setPerx+随机;setPery=setPery+随机
       if(me.zt>59&matrix[17]==1){setPery=setPery-下压幅度}//下压幅度
        if(setPery<0){setPery=360+setPery}else if(setPery>360){setPery=setPery-360}
        if(setPerx<0){setPerx=360+setPerx}else if(setPerx>360){setPerx=setPerx-360}
        
        }

}

function moudle(){
pid=Number(shell("pidof com.tencent.tmgp.pubgmhd",true).result)
if(pid>0){
    shell("cp /proc/"+pid+"/maps /sdcard/maps",true)
    maps=files.read("/sdcard/maps").split("libUE4.so")
    if(maps.length>1){
        maps=maps[0].split("\n")
        return(Number("0x"+maps[maps.length-1].split("-")[0]))
        }
        files.remove("/sdcard/maps")
    }
    return 0
    
    }
    
function 线程注入(){
    shell("am force-stop com.tencent.tmgp.pubgmhd",true)
    模块=0
    while(模块==0){
    模块=moudle()
    }
    //toast(模块)
    }
    
    function 取模块基址(){
var pid=Number(shell("pidof com.tencent.tmgp.pubgmhd",true).result)
var a=(shell("ls /proc/"+pid+"/map_files",true).result).split("\n")
for(i=0;i<a.length-1;i++){
    
   var b=((Number("0x"+a[i].split("-")[1]))-("0x"+a[i].split("-")[0]))
    if(b.toString(16)=="c51000"){
        var c=Number("0x"+a[i].split("-")[0])
        //print(c.toString(16))
        return c;
        }


}
return 0;}

for(var i=0;i<载具.length;i++){
    x=0;y=0
  if(me.x==0){载具[i].f=66}else{载具[i].f=Math.round(Math.sqrt(Math.pow(Math.abs(me.x-载具[i].x),2)+Math.pow(Math.abs(me.y-载具[i].y),2)+Math.pow(Math.abs(me.z-载具[i].z),2))/100)}
  载具[i]={x:(载具[i].x-me.x)/(62.5*2.5/bbb),y:(载具[i].y-me.y)/(62.5*2.5/bbb),f:载具[i].f}
  /*
  if(载具[i].f<=600&matrix.length>=16){//print(matrix[0])
    var obj_x=载具[i].x
    var obj_y=载具[i].y
    var obj_z=载具[i].z+自定义
   		var px=device.height/2
   		var py=device.width/2
var camear_z=matrix[3]*obj_x+matrix[7]*obj_y+matrix[11]*obj_z+matrix[15];

if(camear_z<80){}else{
camear_z=1/camear_z
x=px+(matrix[0]*obj_x+matrix[4]*obj_y+matrix[8]*obj_z+matrix[12])*camear_z*px;
y=py-(matrix[1]*obj_x+matrix[5]*obj_y+matrix[9]*obj_z+matrix[13])*camear_z*py;
}

}
载具[i].X=x;载具[i].Y=y;*/
}

设置画笔颜色(paint,"#75FFFF00")
  for (var i = 0; i < 载具.length; i++){w=45
      if(1==2&载具[i].X!=0){
          jlf=载具[i].name+" "+载具[i].f
          canvas.drawText(jlf,载具[i].X+lhp,载具[i].Y-sxpy,paint载具)
          }
          
          if(载具[i].f>30&载具[i].f<800){jlf=载具[i].f
          if (载具[i].x<-big/2+w/2|载具[i].y<-big/2+w/2|载具[i].x>big/2-w/2|载具[i].y>big/2-w/2){
          var x1=Math.abs(载具[i].x);var y1=Math.abs(载具[i].y);var z1=Math.max(x1,y1)/(big/2-w/2);
          载具[i].x=载具[i].x/z1;载具[i].y=载具[i].y/z1
          }
          canvas.drawLine(dt[0]+载具[i].x-w/2, dt[1]+载具[i].y-w/2, dt[0]+载具[i].x+w/2, dt[1]+载具[i].y+w/2, paint)
     canvas.drawLine(dt[0]+载具[i].x-w/2, dt[1]+载具[i].y+w/2, dt[0]+载具[i].x+w/2, dt[1]+载具[i].y-w/2, paint)
     w=15
     canvas.drawRect(dt[0]+载具[i].x-w/2, dt[1]+载具[i].y-w/2, dt[0]+载具[i].x+w/2, dt[1]+载具[i].y+w/2, paint)
          间距=2
        //+ww/2*0.5
        canvas.drawText(jlf,dt[0]+载具[i].x-ww/2+间距,dt[1]+载具[i].y+ww/2*0.5+间距,paint23阴影)
        canvas.drawText(jlf,dt[0]+载具[i].x-ww/2,dt[1]+载具[i].y+ww/2*0.5,paint23)
          }
          
      }
      设置画笔颜色(paint,"#"+ksdd+ksd2)
  
  
  