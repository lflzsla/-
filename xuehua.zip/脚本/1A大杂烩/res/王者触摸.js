try{
  //  windoww5.close()
 //   windoww6.close()
    windoww7.close()
    }catch(e){}
    
    function 到整数(str){var result=Number(str);if(isNaN(result)){return 0}else{return result}}
    
    
  //  console.show()
可以移动=true

//events.removeAllTouchListeners()
//console.hide()

var 坐标1="100 100"
var 坐标2="100 100"
var 坐标3="100 100"

var window = floaty.window(
    <vertical w="*">
       <button id="a1" text="自动1 (可空)" w="130" h="40" bg="#77ffffff"/>
       <button id="a2" text="自动2 (百里)" w="130" h="40" bg="#77ffffff"/>
       <button id="a3" text="自动3 (可空)" w="130" h="40" bg="#77ffffff"/>
    </vertical>
);
window.setPosition(560,100)
二进制路径=files.cwd()+"/res/cm"
if(files.cwd()=="/storage/emulated/0/1A.Auto.js/1A使命召唤"){二进制路径="/data/data/com.n0n3m4.droidc/files/cm"}
window.a1.click(()=>{
    执行前()
    var name=shell(二进制路径+" "+模拟设备,true).result
    执行后()
    var a=name.split("\n")[0].split(" ")
        if(a.length!=2|到整数(a[0])==0|到整数(a[1])==0){alert("获取失败请重试",name)}else{
    window.a1.setText("x"+a[0]+" y"+a[1])
    坐标1=a[0]+" "+a[1]
    }
    })
    
    window.a2.click(()=>{
        执行前()
    var name=shell(二进制路径+" "+模拟设备,true).result
    执行后()
    var a=name.split("\n")[0].split(" ")
        if(a.length!=2|到整数(a[0])==0|到整数(a[1])==0){alert("获取失败请重试",name)}else{
    window.a2.setText("x"+a[0]+" y"+a[1])
    坐标2=a[0]+" "+a[1]
    }
    })
    
    window.a3.click(()=>{
        执行前()
    var name=shell(二进制路径+" "+模拟设备,true).result
    执行后()
    var a=name.split("\n")[0].split(" ")
        if(a.length!=2|到整数(a[0])==0|到整数(a[1])==0){alert("获取失败请重试",name)}else{
    window.a3.setText("x"+a[0]+" y"+a[1])
    坐标3=a[0]+" "+a[1]
    }
    })
/*
var window = floaty.window(
    <frame>
        <button id="action" text="自动1" w="40" h="40" bg="#77ffffff"/>
    </frame>
);

//setInterval(()=>{}, 1000);

var execution = null;
var x = 0, y = 0;
var windowX, windowY;
var downTime;
window.action.setOnTouchListener(function(view, event){switch(event.getAction()){case event.ACTION_DOWN:
            x = event.getRawX();
            y = event.getRawY();
            windowX = window.getX();
            windowY = window.getY();
            downTime = new Date().getTime();
            return true;
        case event.ACTION_MOVE:
            if(new Date().getTime() - downTime > 1){
                var aa=window.getX()+50
                var bb=window.getY()+50
                //window.action.setText(String(Math.floor(aa+50))+"x"+String(Math.floor(bb+50)))
                window.setPosition(windowX + (event.getRawX() - x),windowY + (event.getRawY() - y));
            }
            return true;
        case event.ACTION_UP:
            //手指弹起时如果偏移很小则判断为点击
            if(Math.abs(event.getRawY() - y) < 5 && Math.abs(event.getRawX() - x) < 5){
                //window.close()
            }
            return true;
    }
    return true;
});


var window2 = floaty.window(
    <frame>
        <button id="action" text="自动2" w="40" h="40" bg="#77ffffff"/>
    </frame>
);

//setInterval(()=>{}, 1000);

var execution = null;
var x = 0, y = 0;
var window2X, window2Y;
var downTime;
window2.action.setOnTouchListener(function(view, event){switch(event.getAction()){case event.ACTION_DOWN:
            x = event.getRawX();
            y = event.getRawY();
            window2X = window2.getX();
            window2Y = window2.getY();
            downTime = new Date().getTime();
            return true;
        case event.ACTION_MOVE:
            if(new Date().getTime() - downTime > 1){
                var aa=window2.getX()+50
                var bb=window2.getY()+50
                //window2.action.setText(String(Math.floor(aa+50))+"x"+String(Math.floor(bb+50)))
                window2.setPosition(window2X + (event.getRawX() - x),window2Y + (event.getRawY() - y));
            }
            return true;
        case event.ACTION_UP:
            //手指弹起时如果偏移很小则判断为点击
            if(Math.abs(event.getRawY() - y) < 5 && Math.abs(event.getRawX() - x) < 5){
                //window2.close()
            }
            return true;
    }
    return true;
});
*/

var window3 = floaty.window(
    <frame>
        <button id="action" text="应用设置" w="80" h="40" bg="#77ffffff"/>
    </frame>
);

//setInterval(()=>{}, 1000);

var execution = null;
var x = 0, y = 0;
var window3X, window3Y;
var downTime;
window3.action.setOnTouchListener(function(view, event){switch(event.getAction()){case event.ACTION_DOWN:
            x = event.getRawX();
            y = event.getRawY();
            window3X = window3.getX();
            window3Y = window3.getY();
            downTime = new Date().getTime();
            return true;
        case event.ACTION_MOVE:
            if(new Date().getTime() - downTime > 1){
                var aa=window3.getX()+50
                var bb=window3.getY()+50
                //window3.action.setText(String(Math.floor(aa+50))+"x"+String(Math.floor(bb+50)))
                //window3.setPosition(window3X + (event.getRawX() - x),window3Y + (event.getRawY() - y));
            }
            return true;
        case event.ACTION_UP:
            //手指弹起时如果偏移很小则判断为点击
            if(Math.abs(event.getRawY() - y) < 5 && Math.abs(event.getRawX() - x) < 5){
                //window3.close()
                /*
                var r=(window.getX()+50-lhp)+" "+(window.getY()+50)+" "+(window2.getX()+50-lhp)+" "+(window2.getY()+50)+" "+(window4.getX()+50-lhp)+" "+(window4.getY()+50)+" "
            window.close()
            window2.close()
            window3.close()
            window4.close()
            */
            //events.removeAllTouchListeners()
            window.close()
            window3.close()
            可以移动=false
            触摸位置=坐标1+" "+坐标2+" "+坐标3+" "
            //触摸位置="603 650 703 500 803 350 "
            alert(触摸位置)
            执行前()
            storage.put("触摸位置",触摸位置)
            threads.start(function(){
            xcxc()
            执行后()
            })
            }
            return true;
    }
    return true;
});

/*

var window4 = floaty.window(
    <frame>
        <button id="action" text="自动3" w="40" h="40" bg="#77ffffff"/>
    </frame>
);

//setInterval(()=>{}, 1000);

var execution = null;
var x = 0, y = 0;
var window4X, window4Y;
var downTime;
window4.action.setOnTouchListener(function(view, event){switch(event.getAction()){case event.ACTION_DOWN:
            x = event.getRawX();
            y = event.getRawY();
            window4X = window4.getX();
            window4Y = window4.getY();
            downTime = new Date().getTime();
            return true;
        case event.ACTION_MOVE:
            if(new Date().getTime() - downTime > 1){
                var aa=window4.getX()+50
                var bb=window4.getY()+50
                //window4.action.setText(String(Math.floor(aa+50))+"x"+String(Math.floor(bb+50)))
                window4.setPosition(window4X + (event.getRawX() - x),window4Y + (event.getRawY() - y));
            }
            return true;
        case event.ACTION_UP:
            //手指弹起时如果偏移很小则判断为点击
            if(Math.abs(event.getRawY() - y) < 5 && Math.abs(event.getRawX() - x) < 5){
                //window4.close()
            }
            return true;
    }
    return true;
});
*/

/*
window.setPosition(463,600)
window2.setPosition(563,450)
window4.setPosition(663,300)
*/
window3.setPosition(60,200)


windoww7 = floaty.window(
    <frame>
        <button id="action" text="百里" w="40" h="40" bg="#77ffffff"/>
    </frame>
);

//setInterval(()=>{}, 1000);

var execution = null;
var x = 0, y = 0;
var windoww7X, windoww7Y;
var downTime;
windoww7.action.setOnTouchListener(function(view, event){switch(event.getAction()){case event.ACTION_DOWN:
            x = event.getRawX();
            y = event.getRawY();
            windoww7X = windoww7.getX();
            windoww7Y = windoww7.getY();
            downTime = new Date().getTime();
            return true;
        case event.ACTION_MOVE:
            if(可以移动&new Date().getTime() - downTime > 1){
                var aa=windoww7.getX()+50
                var bb=windoww7.getY()+50
                //windoww7.action.setText(String(Math.floor(aa+50))+"x"+String(Math.floor(bb+50)))
                windoww7.setPosition(windoww7X + (event.getRawX() - x),windoww7Y + (event.getRawY() - y));
            }
            return true;
        case event.ACTION_UP:
            //手指弹起时如果偏移很小则判断为点击
            if(可以移动==false){zimiaoz.seek(0);zimiaoz.writeBytes("2 ")}
            if(Math.abs(event.getRawY() - y) < 5 && Math.abs(event.getRawX() - x) < 5){
                //windoww7.close()
            }
            return true;
    }
    return true;
});

windoww7.setPosition(360,200)
//windoww6.setPosition(560,100)
//windoww7.setPosition(760,100)


